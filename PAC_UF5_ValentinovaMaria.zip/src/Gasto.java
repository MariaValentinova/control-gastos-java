
public class Gasto extends Dinero{
	//Constructor
	public Gasto(double gasto, String descripcion) {
		super.dinero=gasto;
		super.descripcion=descripcion;
	}
	    //Sobrescritura del m�todo toString
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "Gasto de "+String.format("%.2f",dinero)+" � con el concepto de  "+descripcion+" .";
	}
}
