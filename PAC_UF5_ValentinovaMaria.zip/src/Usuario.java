//Se importa el paquete de java.util.regex para poder realizar comprobaci�n del patr�n de DNI
import java.util.regex.*;
public class Usuario {
	//Atributos
		private String nombre;
		private int edad;
		private String DNI;
		//Constructor vacio y sin par�metros
		public Usuario() {
		}
		//M�todos
		public String getNombre() {
			return nombre;
		}
		public void setNombre(String nombre) {
			this.nombre = nombre;
		}
		public int getEdad() {
			return edad;
		}
		public void setEdad(int edad) {
			this.edad = edad;
		}
		public String getDNI() {
			return DNI;
		}
		//Comprobaci�n del DNI
		public final boolean setDNI(String DNI) {
			Pattern patron=Pattern.compile("^[0-9]{8}-?[a-zA-Z]{1}$");
			Matcher m = patron.matcher(DNI);
			if(m.matches()){
				this.DNI=DNI;
				return true;
			}
			else
				return false;
		}
		//Sobrescritura del m�todo toString
		@Override
		public String toString() {
			// TODO Auto-generated method stub
			return "Usuario Nombre: " +nombre+"\n Edad: "+edad+"\n DNI: "+DNI;
		}
}
