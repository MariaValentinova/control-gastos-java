
public class Ingreso extends Dinero{
	//Constructor
	public Ingreso(double ingreso, String descripcion) {
		super.dinero=ingreso;
		super.descripcion=descripcion;
	}
	//Sobrescritura del m�todo toString
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "Ingreso de "+String.format("%.2f",dinero)+" � con el concepto de "+descripcion+" .";
	}
}
