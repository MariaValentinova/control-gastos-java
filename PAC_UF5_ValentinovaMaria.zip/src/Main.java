import java.util.Scanner;

public class Main {
	public static void main(String[] args) throws GastoException {
		// TODO Auto-generated method stub
		//Declarar variables
        Scanner sc=new Scanner(System.in);
        Usuario usuario=new Usuario();
        String nombre,DNI,descripcion,teclado;
        int edad, select;
        //Pedir datos por consola para crear cuenta de Usuario
        System.out.println("Introduce nombre de Usuario:");
        nombre=sc.next();
        usuario.setNombre(nombre);
        System.out.println("Introduce la edad del Usuario:");
        edad=sc.nextInt();
        usuario.setEdad(edad);
        double dinero;
        //Pedir DNI en formato valido
        do {
			System.out.println("Introduce DNI del Usuario:");
			DNI=sc.next();
			try {
				if(usuario.setDNI(DNI)==false)
					throw new Exception();
			} catch (Exception e) {
				// TODO: handle exception
				System.out.println("El DNI introducido no tiene el formato correcto!");
			}
		} while (!usuario.setDNI(DNI));
        Cuenta usuario1=new Cuenta(usuario);
        System.out.println("La cuenta de Usuario se ha creado correctamente!");
 
        //Pedir al Usuario que realize acciones hasta que marque 0 para salir del programa
        do {
        System.out.println("Realiza una nueva acci�n\n 1 Introduce un nuevo gasto\n 2 Introduce un nuevo ingreso\n 3 Mostrar gastos\n 4 Mostrar ingresos\n "+ "5 Mostrar saldo\n 0 Salir");
            select=Integer.parseInt(sc.next());
            sc.nextLine();
            switch (select) {
			case 1:
				System.out.println("Introduce concepto del gasto:");
				descripcion=sc.nextLine();
				System.out.println("Introduce cantidad:");
				teclado=sc.nextLine();
				teclado=teclado.replaceAll(",",".");
				dinero=Double.valueOf(teclado);
				System.out.println(new Gasto(dinero, descripcion).toString());
				try {usuario1.addGastos(descripcion, dinero);
				}catch(GastoException e) {
					System.out.println("No te lo puedes permitir!Saldo insuficiente!");
				}
				System.out.println("Su saldo actual es de: "+String.format("%.2f",usuario1.getSaldo())+" �.");
				break;
			case 2:
				System.out.println("Introduce concepto del ingreso:");
				descripcion=sc.nextLine();
				System.out.println("Introduce cantidad:");
				teclado=sc.nextLine();
				teclado=teclado.replaceAll(",",".");
				dinero=Double.valueOf(teclado);
				System.out.println(new Ingreso(dinero, descripcion).toString());
				usuario1.addIngresos(descripcion, dinero);
				System.out.println("Su saldo actual es de: "+String.format("%.2f",usuario1.getSaldo())+" �.");
				break;
			case 3:
				usuario1.getGastos();
				break;
			case 4:
				usuario1.getIngresos();    
				break;
			case 5:
				System.out.println("Su saldo es:"+String.format("%.2f",usuario1.getSaldo())+" �.");
				break;
			}
		
	} while (select!=0);
        sc.close();
        System.out.println("Fin del programa.\nGracias por utilizar la aplicaci�n.");
        		
	}

}
