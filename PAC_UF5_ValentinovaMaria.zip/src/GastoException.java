
public class GastoException extends Exception {

	private static final long serialVersionUID = 1L;

	public GastoException() {
		super("No te lo puedes permitir!Saldo insuficiente!");
	}
}
