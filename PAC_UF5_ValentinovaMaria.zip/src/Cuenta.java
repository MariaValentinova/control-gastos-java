 //Importar java.util.ArrayList para poder crear Listas
import java.util.ArrayList;
import java.util.List;
public class Cuenta {
	//Atributos
		private double saldo;
		private Usuario usuario;
		private List <Gasto> gastos;
		private List <Ingreso> ingresos;
		//Constructor y m�todos get y set
		public Cuenta(Usuario usuario) {
			this.usuario=usuario;
			this.gastos=new ArrayList<>();
			this.ingresos=new ArrayList<>();
			this.saldo=0;
		}
		public double getSaldo() {
			return saldo;
		}
		public void setSaldo(double saldo) {
			this.saldo = saldo;
		}
		public Usuario getUsuario() {
			return usuario;
		}
		public void setUsuario(Usuario usuario) {
			this.usuario = usuario;
		}
		//M�todos para agregar gastos y ingresos
		public double addIngresos(String descripcion, double cantidad) {
			this.setSaldo(this.getSaldo() + cantidad);
	        this.ingresos.add(new Ingreso(cantidad, descripcion));
	        return this.getSaldo();
		}
		//Este m�todo lanza una excepci�n si el gasto es mayor que el saldo 
		public double addGastos(String descripcion, double cantidad) throws GastoException {
			if (this.getSaldo() < cantidad) {
	            throw new GastoException();
	        } 
			else {
			this.setSaldo(this.getSaldo() - cantidad);
	        this.gastos.add(new Gasto(cantidad, descripcion));
	        return this.getSaldo();}
		}
		//M�todos Listas
		public List <Ingreso> getIngresos(){
			for(int i=0;i<ingresos.size();i++) {
				System.out.println(ingresos.get(i));
			}
			return ingresos;	
		}
		public List <Gasto> getGastos(){
			for(Gasto g: gastos) {
				System.out.println(g);
			}
			return gastos;
		}
		//Sobrescribir m�todo toString
		@Override
		public String toString() {
			// TODO Auto-generated method stub
			return "El usuario "+usuario+" tiene los siguentes gastos:\n "+gastos+"\n Ingresos:\n"+ingresos+"\n Su saldo es de: "+saldo;
		}
}
